# Samsung — Discover What’s Next (Independent Concept Showcase)

This is an original, fully responsive product showcase microsite concept titled **"Samsung — Discover What’s Next"**, inspired by modern consumer electronics art direction, editorial layouts, and connected living ecosystems.

> **Disclaimer:** This project is an independent conceptual design demonstration and is not sponsored by, endorsed by, or affiliated with Samsung Electronics Co., Ltd.

---

## Features & Interactions

1. **Dismissable Announcement Bar**: Slim dark header strip highlighting upcoming showcase events with smooth dismissal.
2. **Accessible Sticky Navigation & Drawer**:
   - Wordmark logo in official proportions.
   - Smooth backdrop blur.
   - Accessible hamburger menu with full-screen slide-down drawer and keyboard escape support.
   - Live category search overlay supporting keyword matching (`mobile`, `tv`, `home`, `watch`, `audio`).
3. **Hero Section ("Make room for wonder")**:
   - Editorial headline, supporting copy, primary pill CTAs.
   - Hero showcase image with subtle layered orbital radial glows and floating floating titanium spec cards.
4. **Editorial Vision Statement**:
   - Minimalist grid exploring purposeful innovation, ambient intelligence, and human-centric design.
5. **Dark Feature Highlight ("Galaxy Horizon")**:
   - Cinematic split-card layout highlighting mobile innovation with responsive ordering.
6. **Dynamic Product Discovery ("Made for your kind of life")**:
   - Interactive category filter chips (`All Products`, `Mobile`, `TV & Entertainment`, `Home Appliances`, `Wearables`).
   - Smooth client-side JavaScript card filtering and counter updates.
7. **Connected Living Ecosystem ("Living in Sync")**:
   - Pure vector SVG ecosystem topology diagram linking Smartphone, Smart Watch, and OLED Display with animated sync waves.
8. **Interactive VIP Newsletter**:
   - Client-side email syntax validation, stateful pending/success demo transitions, and error tooltips.
9. **Editorial Footer**:
   - Clean columns, official logo presentation, accessibility credits, and clear independent concept disclaimer.

---

## How to Run
Simply open `index.html` in any modern web browser (Chrome, Safari, Edge, Firefox). No backend or build tooling is required.
