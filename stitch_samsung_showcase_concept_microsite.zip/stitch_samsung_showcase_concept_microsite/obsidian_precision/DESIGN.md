---
name: Obsidian Precision
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#c5c5d5'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#8f8f9f'
  outline-variant: '#454653'
  surface-tint: '#bcc3ff'
  primary: '#bcc3ff'
  on-primary: '#011a97'
  primary-container: '#1428a0'
  on-primary-container: '#8f9cff'
  inverse-primary: '#4152c5'
  secondary: '#b9c3ff'
  on-secondary: '#00228a'
  secondary-container: '#1d3bb2'
  on-secondary-container: '#a6b4ff'
  tertiary: '#a2c9ff'
  on-tertiary: '#00315c'
  tertiary-container: '#003b6c'
  on-tertiary-container: '#6da7ef'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dfe0ff'
  primary-fixed-dim: '#bcc3ff'
  on-primary-fixed: '#000d60'
  on-primary-fixed-variant: '#2638ad'
  secondary-fixed: '#dde1ff'
  secondary-fixed-dim: '#b9c3ff'
  on-secondary-fixed: '#001257'
  on-secondary-fixed-variant: '#1939b0'
  tertiary-fixed: '#d3e4ff'
  tertiary-fixed-dim: '#a2c9ff'
  on-tertiary-fixed: '#001c38'
  on-tertiary-fixed-variant: '#004881'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 84px
    letterSpacing: -0.04em
  display-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 60px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '500'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-md-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 30px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.06em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.1em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  gutter-desktop: 2rem
  margin: 2rem
  margin-mobile: 1.25rem
  margin-desktop: 5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style
The design system embodies precision engineering, architectural restraint, and modern luxury. Built for flagship consumer electronics and high-fidelity launch experiences, the aesthetic translates industrial design into an editorial digital surface. 

Visual characteristics balance high-contrast minimalism with luminous depth: deep void spaces, architectural gallery margins, sharp typographic geometry, and smooth pill contours. The experience should evoke the tactile sensations of cold-machined aluminum, polished Corning glass, and pristine OLED displays. Micro-interactions are deliberate and swift, reinforcing an atmosphere of frictionless, state-of-the-art capability.

## Colors
The color architecture operates on absolute contrasts and calibrated luminescences:

- **Primary & Accent Indigo (`#1428A0`, `#032CA6`, `#2B6CB0`):** Reserved for focal points, high-priority interactive calls-to-action, key spec metrics, and optical edge blooms. `#2B6CB0` serves strictly as an active focus glow or interactive state highlight.
- **Canvas Void & Surface Layers (`#0A0A0C`, `#121216`, `#1B1B22`):** Grounded in deep void black to achieve true dynamic range, letting product imagery and high-contrast typography float forward.
- **Pure Gallery Light (`#FFFFFF`, `#F4F4F6`):** Provides razor-sharp legibility across editorial headlines and high-level product titling.
- **Precision Grays (`#8E8E93`, `#3A3A3C`, `#24242A`):** Used for structural metadata, secondary editorial copy, and subtle low-contrast delineation.

Color is deployed with extreme austerity; color should rarely fill large expanses, acting instead as a laser-precise signal of interactivity or critical brand recognition.

## Typography
Typographic rhythm balances the human-engineered modern grotesque curves of Hanken Grotesk with the stark, technical precision of Space Grotesk. 

Display and headline scales rely on tight tracking to produce a disciplined, editorial silhouette suited for hero statements and key product specifications. Body text keeps open line-heights to guarantee instant legibility against dark surfaces. Space Grotesk is strictly leveraged for mono-like technical callouts, category badges, micro-eyebrows, and hardware data points, always styled in uppercase with intentional letter-spacing to mirror industrial chassis engravings.

## Layout & Spacing
The layout follows a 12-column architectural grid on desktop screens, transitioning to 8 columns on tablet viewports and 4 columns on mobile handsets. Large, breathable margins create an intentional exhibition gallery rhythm, allowing standalone hardware renders and typography to command the canvas.

Horizontal alignment demands discipline: hardware specs and hero assets snap precisely to modular vertical lines. Vertical sectioning alternates between tight technical clusters (using `space-xs` and `space-sm`) and generous negative space (multiples of `space-xl`), creating high editorial contrast between analytical spec blocks and immersive hero reveals.

## Elevation & Depth
Elevation eschews conventional drop shadows in favor of ambient lighting, glass refraction, and tonal layering:

- **Surface Levels:** 
  - Canvas: Base `#0A0A0C` (Absolute black).
  - Surface-1: Elevated `#121216` (Cards, spec modules).
  - Surface-2: Floating `#1C1C22` (Modals, popovers, sticky navigation elements).
- **Subtle Edges:** Structural boundaries rely on hairline strokes (`1px solid rgba(255, 255, 255, 0.08)` or `rgba(255, 255, 255, 0.14)` for interactive hover states) rather than diffuse dark drop shadows.
- **Backdrop Diffusion:** Floating headers and glass trays use `backdrop-filter: blur(24px)` with 80% opacity dark backgrounds to subtly diffuse underlying product graphics.
- **Luminous Occlusion:** Key focal elements receive a subtle, wide radial underglow of low-opacity primary indigo (`rgba(20, 40, 160, 0.18)` blur 64px) to replicate self-emissive display technologies.

## Shapes
A dual-tier geometric language drives this system:
1. **Interactive Elements:** Buttons, search bars, tag badges, and quick-filter pills utilize absolute pill radii (`rounded-full`), providing a smooth, ergonomic finish reminiscent of handheld hardware forms.
2. **Container Shells:** Feature cards, spec bento-grids, and modal containers use tailored curvature (`2rem` / `rounded-lg` down to `1rem` on mobile) to frame content cleanly without pinching inner elements.

Inner component radii strictly follow the concentric nesting rule ($R_{outer} - Padding = R_{inner}$) to preserve structural harmony.

## Components

### Buttons
- **Primary Pill:** Background in pure `#FFFFFF` with `#0A0A0C` typography for maximum launch action impact. Hover induces subtle scale (`1.02`) and transforms background to `#F4F4F6`.
- **Secondary Pill:** Dark surface (`#121216`) with `1px solid rgba(255, 255, 255, 0.15)` and white typography. Hover elevates the border to `rgba(255, 255, 255, 0.35)` with an ambient indigo glow.
- **Accent Brand Pill:** Colored background using `#1428A0` with pure white text, designated for immediate purchase or pre-order actions.

### Chips & Badges
- Strict pill silhouette (`rounded-full`), padding `6px 14px`.
- Typography set in `label-sm` (Space Grotesk, uppercase).
- Base style: Semi-transparent fill `rgba(255, 255, 255, 0.05)` with `1px solid rgba(255, 255, 255, 0.1)`. Active states switch to solid white text and a `#1428A0` border edge.

### Spec Bento & Feature Cards
- Dark planar surface (`#121216`) with subtle `1px solid rgba(255, 255, 255, 0.08)` borders.
- Internal spacing set to `space-lg`.
- Top-aligned technical labels paired with large, high-contrast metric callouts (e.g., "0.8mm", "200MP", "NPU 45 TOPS").

### Inputs & Search Bars
- Pill-shaped field contour with an internal height of `48px` or `56px`.
- Background set to `rgba(255, 255, 255, 0.04)` bordered by `rgba(255, 255, 255, 0.12)`.
- Focus state triggers a clean `1px solid #2B6CB0` border and a surrounding 3px focused luminescence halo (`rgba(43, 108, 176, 0.25)`).

### Selection Controls (Checkboxes & Radios)
- Radio elements use a circular pill motif with a concentric `#1428A0` core dot upon selection.
- Checkboxes use `6px` subtle corners with a crisp geometric white checkmark on an active `#1428A0` background.
- Unchecked states maintain a disciplined `1px solid rgba(255, 255, 255, 0.2)` outline against canvas void.

### Hardware Tech Spec Panels
- Monochromatic, borderless row lists separated by hairline dividers (`rgba(255, 255, 255, 0.06)`).
- Left column allocates parameter names in `body-sm` (`#8E8E93`), while right column showcases the engineering spec in `body-md` (`#FFFFFF`).